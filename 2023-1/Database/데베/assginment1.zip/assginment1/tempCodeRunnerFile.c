
    scanf("%d", command);